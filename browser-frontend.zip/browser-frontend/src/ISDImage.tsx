
export interface ISDImage {
  id: string;
  path: string;
  name: string;
  extension: string;
  tags: string[];
  preview: string;
}
